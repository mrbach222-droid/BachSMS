// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "BachBillCore",
    products: [.library(name: "BachBillCore", targets: ["BachBillCore"])],
    targets: [
        .target(name: "BachBillCore", path: "Sources/BachBillCore"),
        .testTarget(name: "BachBillCoreTests", dependencies: ["BachBillCore"], path: "Tests/BachBillCoreTests")
    ]
)
