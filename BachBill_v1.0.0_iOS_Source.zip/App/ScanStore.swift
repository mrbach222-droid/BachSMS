import Foundation
import PhotosUI
import UIKit
import Vision

struct ScanRow: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var orderCode: String
    var contractCode: String
    var amount: Int64?
    var successful: Bool
    var photoFile: String
    var cropTop: Double
    var cropBottom: Double
    var confidence: Float
    var issues: [String]
    var reviewed: Bool = false
    var excluded: Bool = false
    var createdAt: Date = Date()

    var verifiedInvoice: VerifiedInvoice? {
        guard reviewed, !excluded, successful, let amount else { return nil }
        let invoice = VerifiedInvoice(orderCode: orderCode, contractCode: contractCode, amount: amount)
        return InvoiceValidator.valid(invoice) ? invoice : nil
    }
}

struct UnresolvedImage: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    let message: String
    let photoFile: String
}

private struct SavedScan: Codable {
    var rows: [ScanRow]
    var unresolvedImages: [UnresolvedImage]
    var skippedDuplicates: Int
}

struct ScanProgress {
    let current: Int
    let total: Int
}

enum OCRScanner {
    static func scan(data: Data) async throws -> [InvoiceDraft] {
        try await Task.detached(priority: .userInitiated) {
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = false // Prevent plausible-but-wrong ID substitutions.
            request.minimumTextHeight = 0.010
            let supported = (try? request.supportedRecognitionLanguages()) ?? ["en-US"]
            let preferred = ["vi-VN", "en-US"].filter { supported.contains($0) }
            request.recognitionLanguages = preferred.isEmpty ? ["en-US"] : preferred
            let handler = VNImageRequestHandler(data: data, options: [:])
            try handler.perform([request])
            let lines = (request.results ?? []).compactMap { observation -> OCRTextLine? in
                guard let candidate = observation.topCandidates(1).first else { return nil }
                let normalizedTop = 1.0 - Double(observation.boundingBox.maxY)
                return OCRTextLine(text: candidate.string, top: normalizedTop, confidence: candidate.confidence)
            }
            return InvoiceParser.parse(lines)
        }.value
    }
}

@MainActor
final class ScanStore: ObservableObject {
    @Published private(set) var rows: [ScanRow] = []
    @Published private(set) var unresolvedImages: [UnresolvedImage] = []
    @Published private(set) var skippedDuplicates: Int = 0
    @Published var progress: ScanProgress?
    @Published var alertMessage: String?

    init() { restore() }

    private var folder: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("BachBill", isDirectory: true)
    }
    private var dataFile: URL { folder.appendingPathComponent("scans.json") }
    func photoURL(_ row: ScanRow) -> URL { folder.appendingPathComponent(row.photoFile) }
    func photoURL(_ issue: UnresolvedImage) -> URL { folder.appendingPathComponent(issue.photoFile) }

    var verified: [VerifiedInvoice] { rows.compactMap(\.verifiedInvoice) }
    var total: Int64 { InvoiceValidator.total(verified) ?? 0 }
    var pendingCount: Int { rows.filter { !$0.reviewed && !$0.excluded }.count }
    var canExport: Bool {
        !verified.isEmpty && pendingCount == 0 && unresolvedImages.isEmpty &&
        !InvoiceValidator.hasDuplicateOrders(verified) && InvoiceValidator.total(verified) != nil
    }

    func importPhotos(_ selected: [PhotosPickerItem]) async {
        guard !selected.isEmpty, progress == nil else { return }
        for (index, item) in selected.enumerated() {
            progress = ScanProgress(current: index + 1, total: selected.count)
            var savedName = ""
            do {
                guard let bytes = try await item.loadTransferable(type: Data.self),
                      UIImage(data: bytes) != nil else {
                    unresolvedImages.append(UnresolvedImage(message: "Ảnh \(index + 1): không mở được ảnh gốc", photoFile: ""))
                    continue
                }
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let name = UUID().uuidString + ".image"
                savedName = name
                try bytes.write(to: folder.appendingPathComponent(name), options: .atomic)
                let result = try await OCRScanner.scan(data: bytes)
                if result.isEmpty {
                    unresolvedImages.append(UnresolvedImage(message: "Ảnh \(index + 1): chưa tìm thấy đơn hàng", photoFile: name))
                }
                for invoice in result {
                    let new = ScanRow(orderCode: invoice.orderCode,
                        contractCode: invoice.contractCode, amount: invoice.amount,
                        successful: invoice.successful, photoFile: name,
                        cropTop: invoice.cropTop, cropBottom: invoice.cropBottom,
                        confidence: invoice.confidence, issues: invoice.issues)
                    // An identical repeated screenshot must never increase the total.
                    if !new.orderCode.isEmpty && rows.contains(where: {
                        $0.orderCode == new.orderCode && $0.contractCode == new.contractCode &&
                        $0.amount == new.amount && $0.successful == new.successful
                    }) {
                        skippedDuplicates += 1
                        continue
                    }
                    // Conflicting OCR for one ID means both records must be reviewed again.
                    if !new.orderCode.isEmpty {
                        for i in rows.indices where rows[i].orderCode == new.orderCode {
                            rows[i].reviewed = false
                            if !rows[i].issues.contains("Mã đơn trùng nhưng thông tin khác") {
                                rows[i].issues.append("Mã đơn trùng nhưng thông tin khác")
                            }
                        }
                    }
                    var stored = new
                    if rows.contains(where: { !$0.orderCode.isEmpty && $0.orderCode == new.orderCode }) {
                        stored.issues.append("Mã đơn trùng nhưng thông tin khác")
                    }
                    rows.append(stored)
                }
            } catch {
                unresolvedImages.append(UnresolvedImage(message: "Ảnh \(index + 1): lỗi OCR – \(error.localizedDescription)", photoFile: savedName))
            }
            save()
        }
        progress = nil
    }

    func update(_ row: ScanRow) {
        guard let i = rows.firstIndex(where: { $0.id == row.id }) else { return }
        rows[i] = row
        save()
    }

    func dismissUnresolved(_ id: UUID) {
        // Only a deliberate user action can exclude an unreadable source image.
        unresolvedImages.removeAll { $0.id == id }
        save()
    }

    func addManual(from source: UnresolvedImage) {
        rows.append(ScanRow(orderCode: "", contractCode: "", amount: nil,
            successful: false, photoFile: source.photoFile,
            cropTop: 0, cropBottom: 1, confidence: 0,
            issues: ["Đơn nhập thủ công: cần đối chiếu ảnh gốc"]))
        save()
    }

    func clear() {
        rows = []; unresolvedImages = []; skippedDuplicates = 0
        try? FileManager.default.removeItem(at: folder)
    }

    func exportExcel() throws -> URL {
        guard canExport else { throw ExcelExportError.invalidRecords }
        let data = try ExcelWriter.create(verified)
        let formatter = DateFormatter(); formatter.dateFormat = "yyyyMMdd-HHmmss"
        let name = "BachBill-\(formatter.string(from:Date())).xlsx"
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        try data.write(to: path, options: .atomic)
        return path
    }

    private func save() {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(SavedScan(rows: rows, unresolvedImages: unresolvedImages,
                                                           skippedDuplicates: skippedDuplicates))
            try data.write(to: dataFile, options: .atomic)
        } catch { alertMessage = "Không lưu được dữ liệu: \(error.localizedDescription)" }
    }
    private func restore() {
        guard let data = try? Data(contentsOf: dataFile),
              let snapshot = try? JSONDecoder().decode(SavedScan.self, from: data) else { return }
        rows = snapshot.rows; unresolvedImages = snapshot.unresolvedImages
        skippedDuplicates = snapshot.skippedDuplicates
    }
}
