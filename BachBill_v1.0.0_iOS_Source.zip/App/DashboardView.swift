import SwiftUI
import PhotosUI
import UIKit

private enum Palette {
    static let mint = Color(red: 0.24, green: 0.92, blue: 0.74)
    static let bg = Color(red: 0.035, green: 0.07, blue: 0.11)
    static let panel = Color(red: 0.085, green: 0.15, blue: 0.19)
}

private func money(_ amount: Int64) -> String {
    let f = NumberFormatter()
    f.numberStyle = .decimal
    f.groupingSeparator = "."
    f.maximumFractionDigits = 0
    return (f.string(from: NSNumber(value: amount)) ?? String(amount)) + "đ"
}

private struct ExportSheet: Identifiable {
    let id = UUID()
    let url: URL
}

struct DashboardView: View {
    @StateObject private var store = ScanStore()
    @State private var selectedPhotos: [PhotosPickerItem] = []
    @State private var selectedRow: ScanRow?
    @State private var selectedUnresolved: UnresolvedImage?
    @State private var exportSheet: ExportSheet?
    @State private var askClear = false

    var body: some View {
        ZStack {
            Palette.bg.ignoresSafeArea()
            LinearGradient(colors: [Palette.mint.opacity(0.12), .clear, .clear],
                           startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack(alignment: .center) {
                        Image(systemName: "doc.text.viewfinder")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundStyle(Palette.mint)
                            .frame(width: 52, height: 52)
                            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("BÁCH BILL").font(.system(size: 24, weight: .heavy, design: .rounded))
                            Text("Quét ảnh · Kiểm tra số · Xuất Excel")
                                .font(.system(size: 12)).foregroundStyle(.white.opacity(0.65))
                        }
                        Spacer()
                    }
                    .padding(.top, 12)

                    VStack(alignment: .leading, spacing: 16) {
                        Label("TỔNG ĐÃ XÁC NHẬN", systemImage: "checkmark.shield.fill")
                            .font(.system(size: 12, weight: .bold)).foregroundStyle(Palette.mint)
                        Text(money(store.total))
                            .font(.system(size: 36, weight: .heavy, design: .rounded))
                            .minimumScaleFactor(0.65).lineLimit(1)
                            .contentTransition(.numericText())
                        HStack(spacing: 16) {
                            stat("\(store.rows.count)", "Đã nhận diện")
                            stat("\(store.verified.count)", "Đã xác nhận")
                            stat("\(store.pendingCount)", "Chờ kiểm tra")
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [Palette.panel, Palette.bg],
                                               startPoint: .topLeading, endPoint: .bottomTrailing),
                                in: RoundedRectangle(cornerRadius: 24))
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(Palette.mint.opacity(0.23)))

                    PhotosPicker(selection: $selectedPhotos, maxSelectionCount: 50,
                                 matching: .images, photoLibrary: .shared()) {
                        HStack(spacing: 12) {
                            Image(systemName: "plus.viewfinder").font(.system(size: 24, weight: .medium))
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Chọn ảnh để quét").font(.system(size: 17, weight: .bold))
                                Text("Chọn nhiều ảnh · Không cần API · Xử lý trên máy")
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundStyle(Palette.bg.opacity(0.75))
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .foregroundStyle(Palette.bg)
                        .padding(16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Palette.mint, in: RoundedRectangle(cornerRadius: 18))
                    }
                    .disabled(store.progress != nil)

                    if let progress = store.progress {
                        HStack(spacing: 10) {
                            ProgressView().tint(Palette.mint)
                            Text("Đang đọc ảnh \(progress.current)/\(progress.total)…")
                                .font(.subheadline)
                        }
                        .padding(12)
                    }

                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "exclamationmark.shield.fill").foregroundStyle(.yellow)
                        Text("Để tránh sai 1 chữ số, mỗi hợp đồng phải được mở ảnh gốc và xác nhận trước khi cộng vào tổng chính thức.")
                            .font(.system(size: 12)).foregroundStyle(.white.opacity(0.75))
                    }

                    if store.skippedDuplicates > 0 {
                        Label("Đã bỏ qua \(store.skippedDuplicates) lần quét trùng khớp.", systemImage: "doc.on.doc")
                            .font(.footnote).foregroundStyle(Palette.mint)
                    }
                    ForEach(store.unresolvedImages) { issue in
                        Button { selectedUnresolved = issue } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(issue.message).font(.footnote.bold())
                                    Text("Mở ảnh gốc · Nhập thủ công hoặc bỏ qua")
                                        .font(.caption2).foregroundStyle(.white.opacity(0.65))
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                            }
                            .padding(14).background(.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                        }.buttonStyle(.plain)
                    }

                    HStack {
                        Text("CHI TIẾT HỢP ĐỒNG").font(.system(size: 13, weight: .bold))
                        Spacer()
                        if !store.rows.isEmpty {
                            Button("Xóa tất cả", role: .destructive) { askClear = true }
                                .font(.system(size: 12))
                        }
                    }
                    .padding(.top, 8)

                    if store.rows.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "rectangle.stack.badge.plus")
                                .font(.system(size: 38)).foregroundStyle(Palette.mint.opacity(0.65))
                            Text("Chưa có hóa đơn").font(.headline)
                            Text("Bắt đầu bằng ảnh chụp danh sách giao dịch, hóa đơn hoặc biên lai.")
                                .font(.footnote).multilineTextAlignment(.center)
                                .foregroundStyle(.white.opacity(0.57))
                        }
                        .frame(maxWidth: .infinity).padding(35)
                        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
                    } else {
                        ForEach(store.rows) { row in
                            Button { selectedRow = row } label: {
                                invoiceTile(row)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    Button {
                        do { exportSheet = ExportSheet(url: try store.exportExcel()) }
                        catch { store.alertMessage = "Không xuất được Excel. Kiểm tra các đơn còn thiếu hoặc trùng." }
                    } label: {
                        HStack {
                            Image(systemName: "square.and.arrow.up.fill")
                            Text("Xuất Excel (.xlsx)").bold()
                            Spacer()
                            Text("\(store.verified.count) đơn")
                        }
                        .padding(17).frame(maxWidth: .infinity)
                        .background(store.canExport ? Palette.mint : .white.opacity(0.14),
                                    in: RoundedRectangle(cornerRadius: 17))
                        .foregroundStyle(store.canExport ? Palette.bg : .white.opacity(0.5))
                    }
                    .disabled(!store.canExport)
                    if !store.canExport && !store.rows.isEmpty {
                        Text("Xuất Excel sẽ mở khi mọi ảnh và hợp đồng đã được xử lý, không còn đơn chờ xác nhận hay mã trùng.")
                            .font(.caption).foregroundStyle(.white.opacity(0.55))
                    }
                    Text("Dữ liệu và ảnh gốc lưu trên iPhone. Không chuyển lên máy chủ.")
                        .font(.caption2).foregroundStyle(.white.opacity(0.45))
                        .frame(maxWidth: .infinity)
                }
                .padding(18)
            }
        }
        .onChange(of: selectedPhotos) { _, selection in
            Task {
                await store.importPhotos(selection)
                selectedPhotos = []
            }
        }
        .sheet(item: $selectedRow) { row in
            InvoiceReviewView(row: row, photoURL: store.photoURL(row)) { updated in
                store.update(updated)
            }
        }
        .sheet(item: $selectedUnresolved) { issue in
            UnreadableImageView(issue: issue, photoURL: store.photoURL(issue),
                onAdd: { store.addManual(from: issue) },
                onResolve: { store.dismissUnresolved(issue.id) })
        }
        .sheet(item: $exportSheet) { exported in
            ActivityShareSheet(url: exported.url)
        }
        .confirmationDialog("Xóa mọi hợp đồng và ảnh đã lưu?", isPresented: $askClear,
                            titleVisibility: .visible) {
            Button("Xóa toàn bộ", role: .destructive) { store.clear() }
        }
        .alert("Bách Bill", isPresented: Binding(
            get: { store.alertMessage != nil },
            set: { if !$0 { store.alertMessage = nil } }
        )) { Button("Đóng", role: .cancel) { store.alertMessage = nil } } message: {
            Text(store.alertMessage ?? "")
        }
    }

    private func stat(_ value: String, _ label: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(value).font(.title2.bold().monospacedDigit())
            Text(label).font(.system(size: 10)).foregroundStyle(.white.opacity(0.55))
        }.frame(maxWidth: .infinity, alignment: .leading)
    }

    private func invoiceTile(_ row: ScanRow) -> some View {
        HStack(spacing: 12) {
            Image(systemName: row.excluded ? "minus.circle.fill" : row.reviewed ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                .font(.system(size: 25))
                .foregroundStyle(row.excluded ? .gray : row.reviewed ? Palette.mint : .orange)
            VStack(alignment: .leading, spacing: 5) {
                Text(row.contractCode.isEmpty ? "Chưa đọc được hợp đồng" : row.contractCode)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                Text("#\(row.orderCode.isEmpty ? "Chưa xác định" : row.orderCode)")
                    .font(.system(size: 12)).foregroundStyle(.white.opacity(0.58))
                Text(row.excluded ? "Đã loại khỏi tổng" : row.reviewed ? "Đã đối chiếu ảnh gốc" : "Chạm để kiểm tra ảnh")
                    .font(.system(size: 11)).foregroundStyle(row.reviewed ? Palette.mint : .orange)
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 6) {
                Text(row.amount.map(money) ?? "Chưa rõ")
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.7).lineLimit(1)
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.36))
            }
        }
        .padding(14).background(Palette.panel.opacity(0.8), in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct ActivityShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
