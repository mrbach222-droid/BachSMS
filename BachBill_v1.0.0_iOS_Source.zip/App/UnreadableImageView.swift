import SwiftUI
import UIKit

struct UnreadableImageView: View {
    @Environment(\.dismiss) private var dismiss
    let issue: UnresolvedImage
    let photoURL: URL
    let onAdd: () -> Void
    let onResolve: () -> Void
    @State private var addedCount = 0

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Label(issue.message, systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange).font(.headline)
                    if let bytes = try? Data(contentsOf: photoURL), let image = UIImage(data: bytes) {
                        Image(uiImage: image).resizable().scaledToFit()
                            .frame(maxWidth: .infinity).background(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    } else {
                        Text("Ảnh gốc không khả dụng. Hãy chọn nhập lại ảnh rõ hơn.")
                            .foregroundStyle(.orange)
                    }
                    Text("Nếu ảnh có nhiều hợp đồng, bấm Thêm hợp đồng nhiều lần rồi điền riêng từng đơn ở màn hình chính.")
                        .font(.footnote)
                    Button {
                        onAdd(); addedCount += 1
                    } label: {
                        Label("Thêm hợp đồng từ ảnh này", systemImage: "plus.circle.fill")
                            .frame(maxWidth: .infinity).padding(14)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!FileManager.default.fileExists(atPath: photoURL.path))
                    if addedCount > 0 {
                        Text("Đã tạo \(addedCount) dòng nhập tay. Chúng vẫn chờ xác nhận ảnh gốc.")
                            .font(.footnote).foregroundStyle(.green)
                    }
                    Button(role: .destructive) {
                        onResolve(); dismiss()
                    } label: {
                        Text("Tôi đã kiểm tra ảnh và xử lý đủ các hợp đồng")
                            .frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.bordered)
                }
                .padding(16)
            }
            .navigationTitle("Ảnh cần xử lý")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() } } }
        }
    }
}
