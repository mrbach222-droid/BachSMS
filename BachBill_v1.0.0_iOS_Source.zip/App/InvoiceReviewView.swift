import SwiftUI
import UIKit

struct InvoiceReviewView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var edited: ScanRow
    @State private var amountText: String
    @State private var expandPhoto = false

    let photoURL: URL
    let onSave: (ScanRow) -> Void

    init(row: ScanRow, photoURL: URL, onSave: @escaping (ScanRow) -> Void) {
        _edited = State(initialValue: row)
        _amountText = State(initialValue: row.amount.map(String.init) ?? "")
        self.photoURL = photoURL
        self.onSave = onSave
    }

    private var parsedAmount: Int64? { VNDParser.parse(amountText) }
    private var canVerify: Bool {
        guard edited.successful, let value = parsedAmount else { return false }
        return InvoiceValidator.valid(VerifiedInvoice(orderCode: edited.orderCode,
                           contractCode: edited.contractCode, amount: value))
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("ẢNH GỐC – ĐỐI CHIẾU TỪNG CHỮ SỐ") {
                    if let data = try? Data(contentsOf: photoURL), let original = UIImage(data: data) {
                        let preview = expandPhoto ? original : (crop(original) ?? original)
                        Image(uiImage: preview).resizable().scaledToFit()
                            .frame(maxWidth: .infinity).background(.white)
                        Button(expandPhoto ? "Thu gọn ảnh" : "Xem toàn bộ ảnh gốc") { expandPhoto.toggle() }
                    } else {
                        Label("Không tìm thấy ảnh gốc. Không được xác nhận khi chưa đối chiếu.",
                              systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.orange)
                    }
                }
                Section("THÔNG TIN ĐÃ NHẬN DIỆN") {
                    LabeledContent("Mã đơn hàng") {
                        TextField("7–14 chữ số", text: $edited.orderCode)
                            .textInputAutocapitalization(.never).keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }
                    LabeledContent("Số hợp đồng") {
                        TextField("Mã hợp đồng", text: $edited.contractCode)
                            .textInputAutocapitalization(.characters).autocorrectionDisabled()
                            .multilineTextAlignment(.trailing)
                    }
                    LabeledContent("Số tiền (VND)") {
                        TextField("Ví dụ: 856589", text: $amountText)
                            .keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                    }
                    if let number = parsedAmount {
                        Text("Số tiền sẽ cộng: \(number) VND")
                            .font(.footnote).foregroundStyle(.green)
                    } else {
                        Text("Số tiền phải là số nguyên hợp lệ (ví dụ 856.589). Không làm tròn.")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                    LabeledContent("Trạng thái") {
                        Text(edited.successful ? "Thành công" : "Chưa chắc / thất bại")
                            .foregroundStyle(edited.successful ? .green : .orange)
                    }
                    Toggle("Đã đối chiếu giao dịch thành công trên ảnh", isOn: $edited.successful)
                        .font(.footnote)
                }
                if !edited.issues.isEmpty {
                    Section("CẢNH BÁO KHI ĐỌC ẢNH") {
                        ForEach(edited.issues, id: \.self) { problem in
                            Label(problem, systemImage: "exclamationmark.triangle")
                                .font(.footnote).foregroundStyle(.orange)
                        }
                    }
                }
                Section {
                    Button {
                        guard let data = try? Data(contentsOf: photoURL), UIImage(data:data) != nil,
                              let amount = parsedAmount, canVerify else { return }
                        edited.amount = amount
                        edited.reviewed = true
                        edited.excluded = false
                        edited.contractCode = edited.contractCode.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
                        edited.orderCode = edited.orderCode.trimmingCharacters(in: .whitespacesAndNewlines)
                        onSave(edited); dismiss()
                    } label: {
                        Label("Xác nhận chính xác – tính vào tổng", systemImage: "checkmark.shield")
                            .frame(maxWidth: .infinity)
                    }
                    .disabled(!canVerify || !FileManager.default.fileExists(atPath: photoURL.path))
                    Button(role: .destructive) {
                        edited.excluded = true; edited.reviewed = false
                        onSave(edited); dismiss()
                    } label: {
                        Label("Loại đơn này khỏi tổng", systemImage: "minus.circle")
                            .frame(maxWidth: .infinity)
                    }
                } footer: {
                    Text("Chỉ xác nhận sau khi tự so sánh từng chữ số trên ảnh gốc. Đơn không xác nhận không bao giờ được cộng.")
                }
            }
            .navigationTitle("Kiểm tra hợp đồng")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() } }
            }
        }
    }

    private func crop(_ image: UIImage) -> UIImage? {
        guard let imageCG = image.cgImage else { return nil }
        let height = CGFloat(edited.cropBottom - edited.cropTop)
        guard height > 0 else { return nil }
        let rect = CGRect(x: 0, y: CGFloat(edited.cropTop) * CGFloat(imageCG.height),
                          width: CGFloat(imageCG.width), height: height * CGFloat(imageCG.height))
            .intersection(CGRect(x:0,y:0,width:CGFloat(imageCG.width),height:CGFloat(imageCG.height)))
        guard let part = imageCG.cropping(to: rect) else { return nil }
        return UIImage(cgImage: part)
    }
}
