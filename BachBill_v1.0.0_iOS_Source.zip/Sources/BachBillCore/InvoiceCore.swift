import Foundation

public struct OCRTextLine: Sendable {
    public let text: String
    /// Normalized position from the TOP of the picture (0…1).
    public let top: Double
    public let confidence: Float

    public init(text: String, top: Double, confidence: Float) {
        self.text = text; self.top = top; self.confidence = confidence
    }
}

public struct InvoiceDraft: Sendable {
    public let orderCode: String
    public let contractCode: String
    public let amount: Int64?
    public let successful: Bool
    public let cropTop: Double
    public let cropBottom: Double
    public let confidence: Float
    public let issues: [String]
}

public enum VNDParser {
    /// No rounding and no guesses about 2-digit decimals or malformed thousands groups.
    public static func parse(_ value: String) -> Int64? {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let digitsOnly = trimmed.range(of: #"^[0-9]+$"#, options: .regularExpression) != nil
        let grouped = trimmed.range(of: #"^[0-9]{1,3}([.,][0-9]{3})+$"#, options: .regularExpression) != nil
        guard digitsOnly || grouped else { return nil }
        let number = trimmed.replacingOccurrences(of: ".", with: "").replacingOccurrences(of: ",", with: "")
        guard let n = Int64(number), n > 0, n <= 999_999_999_999 else { return nil }
        return n
    }
}

public enum InvoiceParser {
    private static func normalized(_ raw: String) -> String {
        raw.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "vi_VN"))
            .replacingOccurrences(of: "Đ", with: "D").replacingOccurrences(of: "đ", with: "d")
            .lowercased()
    }
    private static func capture(_ pattern: String, text: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              match.numberOfRanges > 1,
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }

    public static func parse(_ lines: [OCRTextLine]) -> [InvoiceDraft] {
        let ordered = lines.sorted { $0.top < $1.top }
        let headings = ordered.filter { normalized($0.text).contains("don hang") }
        guard !headings.isEmpty else { return [] }
        return headings.enumerated().map { position, heading in
            // Status is in a different column but at the SAME height as the order ID.
            // Vision may return it slightly before the order header in reading order.
            let startTop = max(0, heading.top - 0.025)
            let endTop = position + 1 < headings.count ? max(startTop + 0.001, headings[position + 1].top - 0.025) : 1.001
            let group = ordered.filter { $0.top >= startTop && $0.top < endTop }
            let content = group.map { normalized($0.text) }
            let headerText = normalized(heading.text)
            let order = capture(#"don\s*hang\s*[:：]?\s*#?\s*([0-9]{7,14})"#, text: headerText) ?? ""
            var contract = ""
            var amount: Int64?
            var status = false
            var hasSuccess = false
            var hasFailure = false
            var confidence = group.first?.confidence ?? 0
            var issues: [String] = []
            for (i, text) in content.enumerated() {
                if text.contains("so hop dong") {
                    contract = capture(#"so\s*hop\s*dong\s*[:：]?\s*([a-z0-9]{9,22})"#, text: text)?.uppercased() ?? ""
                    if contract.isEmpty && i + 1 < content.count {
                        contract = capture(#"^\s*([a-z0-9]{9,22})\s*$"#, text: content[i + 1])?.uppercased() ?? ""
                    }
                    confidence = min(confidence, group[i].confidence)
                }
                if text.contains("tong tien") {
                    // Preserve separators, never interpret a malformed amount as a valid one.
                    let tail = text.components(separatedBy: ":").dropFirst().joined(separator: ":")
                    let source = tail.isEmpty ? text.replacingOccurrences(of: "tong tien", with: "") : tail
                    if let raw = capture(#"^\s*([0-9][0-9.,]*)"#, text: source) {
                        amount = VNDParser.parse(raw)
                    }
                    if amount == nil && i + 1 < content.count,
                       let raw = capture(#"^\s*([0-9][0-9.,]*)"#, text: content[i + 1]) {
                        amount = VNDParser.parse(raw)
                    }
                    confidence = min(confidence, group[i].confidence)
                }
                if text.contains("thanh cong") { hasSuccess = true }
                if text.contains("that bai") || text.contains("da huy") { hasFailure = true }
            }
            status = hasSuccess && !hasFailure
            if order.isEmpty { issues.append("Không đọc chắc mã đơn hàng") }
            if contract.isEmpty { issues.append("Không đọc chắc số hợp đồng") }
            if amount == nil { issues.append("Số tiền trống hoặc không đúng định dạng") }
            if !status { issues.append("Chưa xác nhận được trạng thái thành công") }
            if confidence < 0.90 { issues.append("Độ tin cậy OCR thấp; cần xem ảnh gốc") }
            let cropTop = max(0, heading.top - 0.012)
            let cropBottom = position + 1 < headings.count
                ? min(1, headings[position + 1].top - 0.01)
                : min(1, (group.last?.top ?? 1) + 0.115)
            return InvoiceDraft(orderCode: order, contractCode: contract, amount: amount,
                successful: status, cropTop: cropTop, cropBottom: max(cropTop + 0.01, cropBottom),
                confidence: confidence, issues: issues)
        }
    }
}

public struct VerifiedInvoice: Sendable {
    public let orderCode: String
    public let contractCode: String
    public let amount: Int64
    public init(orderCode: String, contractCode: String, amount: Int64) {
        self.orderCode = orderCode; self.contractCode = contractCode; self.amount = amount
    }
}

public enum InvoiceValidator {
    public static func valid(_ invoice: VerifiedInvoice) -> Bool {
        invoice.orderCode.range(of: #"^[0-9]{7,14}$"#, options: .regularExpression) != nil &&
        invoice.contractCode.range(of: #"^[A-Za-z0-9]{9,22}$"#, options: .regularExpression) != nil &&
        invoice.amount > 0
    }
    public static func total(_ invoices: [VerifiedInvoice]) -> Int64? {
        var sum: Int64 = 0
        for item in invoices {
            guard valid(item) else { return nil }
            let (n, overflow) = sum.addingReportingOverflow(item.amount)
            guard !overflow else { return nil }
            sum = n
        }
        return sum
    }
    public static func hasDuplicateOrders(_ invoices: [VerifiedInvoice]) -> Bool {
        Set(invoices.map(\.orderCode)).count != invoices.count
    }
}
