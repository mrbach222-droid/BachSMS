import Foundation

public enum ExcelExportError: Error { case invalidRecords, duplicateOrders, overflow, zipTooLarge }

public enum ExcelWriter {
    public static func create(_ records: [VerifiedInvoice]) throws -> Data {
        guard !records.isEmpty, records.allSatisfy(InvoiceValidator.valid) else { throw ExcelExportError.invalidRecords }
        guard !InvoiceValidator.hasDuplicateOrders(records) else { throw ExcelExportError.duplicateOrders }
        guard let total = InvoiceValidator.total(records) else { throw ExcelExportError.overflow }
        let last = records.count + 1
        let totalRow = last + 1
        var lines = ["""
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
        <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
        <cols><col min="1" max="1" width="8" customWidth="1"/><col min="2" max="2" width="19" customWidth="1"/><col min="3" max="3" width="24" customWidth="1"/><col min="4" max="4" width="21" customWidth="1"/><col min="5" max="5" width="20" customWidth="1"/></cols>
        <sheetData>
        <row r="1">\(stringCell("A1", "STT", style:1))\(stringCell("B1", "Mã đơn hàng", style:1))\(stringCell("C1", "Số hợp đồng", style:1))\(stringCell("D1", "Số tiền (VND)", style:1))\(stringCell("E1", "Trạng thái", style:1))</row>
        """]
        for (index, item) in records.enumerated() {
            let row = index + 2
            lines.append("<row r=\"\(row)\"><c r=\"A\(row)\"><v>\(index + 1)</v></c>\(stringCell("B\(row)", item.orderCode))\(stringCell("C\(row)", item.contractCode))<c r=\"D\(row)\" s=\"2\"><v>\(item.amount)</v></c>\(stringCell("E\(row)", "Đã xác nhận"))</row>")
        }
        lines.append("<row r=\"\(totalRow)\">\(stringCell("C\(totalRow)", "TỔNG CỘNG", style:3))<c r=\"D\(totalRow)\" s=\"4\"><f>SUM(D2:D\(last))</f><v>\(total)</v></c></row>")
        lines.append("</sheetData><autoFilter ref=\"A1:E\(last)\"/></worksheet>")
        let sheet = lines.joined(separator: "\n")
        let entries: [(String, String)] = [
            ("[Content_Types].xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>
            """),
            ("_rels/.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>
            """),
            ("xl/workbook.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Chi tiet hoa don" sheetId="1" r:id="rId1"/></sheets></workbook>
            """),
            ("xl/_rels/workbook.xml.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>
            """),
            ("xl/styles.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Aptos"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Aptos"/></font><font><b/><sz val="11"/><color rgb="FF0F766E"/><name val="Aptos"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0F766E"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="164" fontId="2" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>
            """),
            ("xl/worksheets/sheet1.xml", sheet)
        ]
        return try StoredZIP.make(entries.map { ($0.0, Data($0.1.utf8)) })
    }

    private static func xml(_ source: String) -> String {
        source.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&apos;")
    }
    private static func stringCell(_ cell: String, _ value: String, style: Int = 0) -> String {
        "<c r=\"\(cell)\" t=\"inlineStr\" s=\"\(style)\"><is><t xml:space=\"preserve\">\(xml(value))</t></is></c>"
    }
}

private enum StoredZIP {
    static func make(_ entries: [(String, Data)]) throws -> Data {
        var output = Data(), central = Data()
        for (name, data) in entries {
            let nameBytes = Data(name.utf8)
            guard data.count <= UInt32.max, nameBytes.count <= UInt16.max, output.count <= UInt32.max else { throw ExcelExportError.zipTooLarge }
            let crc = crc32(data)
            let offset = UInt32(output.count)
            output.u32(0x04034B50); output.u16(20); output.u16(0); output.u16(0)
            output.u16(0); output.u16(0); output.u32(crc)
            output.u32(UInt32(data.count)); output.u32(UInt32(data.count))
            output.u16(UInt16(nameBytes.count)); output.u16(0)
            output.append(nameBytes); output.append(data)
            central.u32(0x02014B50); central.u16(20); central.u16(20)
            central.u16(0); central.u16(0); central.u16(0); central.u16(0)
            central.u32(crc); central.u32(UInt32(data.count)); central.u32(UInt32(data.count))
            central.u16(UInt16(nameBytes.count)); central.u16(0); central.u16(0)
            central.u16(0); central.u16(0); central.u32(0); central.u32(offset)
            central.append(nameBytes)
        }
        guard output.count <= UInt32.max, central.count <= UInt32.max, entries.count <= UInt16.max else { throw ExcelExportError.zipTooLarge }
        let centralStart = UInt32(output.count)
        output.append(central)
        output.u32(0x06054B50); output.u16(0); output.u16(0)
        output.u16(UInt16(entries.count)); output.u16(UInt16(entries.count))
        output.u32(UInt32(central.count)); output.u32(centralStart); output.u16(0)
        return output
    }
    private static func crc32(_ data: Data) -> UInt32 {
        var result: UInt32 = 0xFFFF_FFFF
        for byte in data {
            result ^= UInt32(byte)
            for _ in 0..<8 { result = (result >> 1) ^ (result & 1 == 1 ? 0xEDB88320 : 0) }
        }
        return ~result
    }
}
private extension Data {
    mutating func u16(_ value: UInt16) { append(UInt8(value & 0xFF)); append(UInt8((value >> 8) & 0xFF)) }
    mutating func u32(_ value: UInt32) { u16(UInt16(value & 0xFFFF)); u16(UInt16((value >> 16) & 0xFFFF)) }
}
