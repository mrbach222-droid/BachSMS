# Bách Bill v1.0.0 — native iOS

**Một ứng dụng iPhone thực, không phải bản web được thu phóng.** Viết bằng SwiftUI, Apple Vision OCR, lưu dữ liệu cục bộ, xuất Excel XLSX chuẩn Office Open XML.

## Những gì đã triển khai
- Nhập tới 50 ảnh/lần qua PhotosPicker; ảnh được lưu bản gốc trên iPhone.
- Apple Vision OCR chạy cục bộ, không cần API key và không gửi hóa đơn lên máy chủ.
- Tìm mã đơn hàng, mã hợp đồng, số tiền, trạng thái giao dịch theo từng khối hóa đơn. Không tự đổi `O` thành `0`, không tự làm tròn tiền.
- Mã đơn trùng + toàn bộ thông tin trùng: tự bỏ qua. Mã đơn trùng nhưng số liệu khác: cả hai chờ kiểm tra.
- Số tiền không rõ, sai định dạng, trạng thái thất bại hoặc mất mã: luôn chờ người dùng sửa/loại.
- **Mọi dòng phải đối chiếu ảnh gốc và nhấn Xác nhận.** Chỉ khi đó mới tính vào tổng và mới có thể xuất Excel. Ảnh chưa đọc được tạo cảnh báo phải xử lý riêng.
- Lưu lần quét, sửa, loại khỏi tổng, xoá toàn bộ; Excel .xlsx có mã đơn, hợp đồng, tiền, trạng thái và tổng SUM có cache.

## Giới hạn quan trọng
- Không một hệ thống OCR nào có thể đảm bảo 100% số chính xác với mọi ảnh. Quy trình này **ngăn số chưa xác minh đi vào tổng**, chứ không tuyên bố OCR hoàn hảo.
- Phiên bản 1 nhận diện **bố cục danh sách thanh toán tiền điện Thế Giới Di Động** giống ba ảnh kiểm thử, chưa hỗ trợ mọi kiểu bảng/hóa đơn hay ảnh bị cắt quá nhiều.
- Chưa có extension nhận ảnh trực tiếp từ menu Chia sẻ của iOS; hiện chọn ảnh trong ứng dụng.
- Chưa build/kiểm thử trên macOS hoặc iPhone thực trong môi trường này. Muốn có IPA, chạy GitHub Actions macOS hoặc Xcode. IPA workflow là **unsigned** để người dùng ký bằng chứng chỉ của mình.

## Dùng với GitHub
1. Tạo repo **private** mới `BachBill` trong tài khoản GitHub của bạn (không dùng chung các repo BachSMS, ViThe).
2. Giải nén dự án ZIP, tải toàn bộ nội dung lên nhánh `main`, gồm thư mục `.github/workflows`.
3. Mở **Actions → Build BachBill IPA → Run workflow**.
4. Nếu build xanh, lấy artifact `BachBill-v1.0.0-unsigned` chứa IPA chưa ký, ký bằng chứng chỉ phù hợp (ví dụ zSign) để cài trên iPhone.

## Kiểm thử phần lõi
```bash
swift test
```
Bộ unit test kiểm tra 12 khoản tiền với mã đơn/mã hợp đồng kiểm thử giả lập (tổng 10.978.565đ), trùng mã, số tiền sai định dạng, giao dịch thất bại, status ngang hàng và kết cấu XLSX. Unit test không thay thế kiểm thử Apple Vision trên ảnh thật.

## Xcode trên macOS
```bash
brew install xcodegen
xcodegen generate
open BachBill.xcodeproj
```
Chọn thiết bị iPhone trong Xcode; cấu hình Team & Signing nếu muốn cài bản ký trực tiếp. iOS tối thiểu 17.0.

### Ảnh OCR không nhận ra đơn hàng
Ứng dụng hiện cảnh báo bắt buộc. Chạm vào cảnh báo để mở ảnh gốc, tạo thủ công từng hợp đồng còn thiếu (có thể tạo nhiều dòng), kiểm tra rồi xác nhận từng dòng. Chỉ khi chủ động hoàn tất xử lý ảnh đó mới mở khoá xuất Excel.
