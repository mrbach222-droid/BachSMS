import XCTest
@testable import BachBillCore

final class InvoiceCoreTests: XCTestCase {
    private let fixtures: [(String, String, Int64)] = [
        ("130000001","TESTBILL00001",856589),
        ("130000002","TESTBILL00002",827095),
        ("130000003","TESTBILL00003",845528),
        ("130000004","TESTBILL00004",849215),
        ("130000005","TESTBILL00005",967191),
        ("130000006","TESTBILL00006",952444),
        ("130000007","TESTBILL00007",952444),
        ("130000008","TESTBILL00008",958838),
        ("130000009","TESTBILL00009",959817),
        ("130000010","TESTBILL00010",934010),
        ("130000011","TESTBILL00011",934010),
        ("130000012","TESTBILL00012",941384)
    ]

    func testTwelveInvoicesExactly() throws {
        let source = fixtures.enumerated().flatMap { (idx, f) -> [OCRTextLine] in
            let y = Double(idx) * 0.08
            return [
                OCRTextLine(text:"Đơn hàng: #\(f.0)", top:y, confidence:0.99),
                OCRTextLine(text:"Thành công", top:y + 0.01, confidence:0.99),
                OCRTextLine(text:"Số hợp đồng: \(f.1)", top:y + 0.02, confidence:0.99),
                OCRTextLine(text:"Tổng tiền: \(f.2.formatted(.number.grouping(.never)))đ", top:y + 0.03, confidence:0.99)
            ]
        }
        let rows = InvoiceParser.parse(source)
        XCTAssertEqual(rows.count, 12)
        for (row, expected) in zip(rows, fixtures) {
            XCTAssertEqual(row.orderCode, expected.0)
            XCTAssertEqual(row.contractCode, expected.1)
            XCTAssertEqual(row.amount, expected.2)
            XCTAssertTrue(row.successful)
            XCTAssertTrue(row.issues.isEmpty, "\(row.issues)")
        }
        let checked = rows.compactMap { row -> VerifiedInvoice? in
            guard let amount = row.amount else { return nil }
            return VerifiedInvoice(orderCode:row.orderCode, contractCode:row.contractCode, amount:amount)
        }
        XCTAssertFalse(InvoiceValidator.hasDuplicateOrders(checked))
        XCTAssertEqual(InvoiceValidator.total(checked), 10_978_565)
    }

    func testVietnameseAmountsFailClosed() {
        XCTAssertEqual(VNDParser.parse("856.589"), 856589)
        XCTAssertEqual(VNDParser.parse("1,234,567"), 1234567)
        XCTAssertEqual(VNDParser.parse("856589"), 856589)
        XCTAssertNil(VNDParser.parse("856.58"))
        XCTAssertNil(VNDParser.parse("856,589.00"))
        XCTAssertNil(VNDParser.parse("856.58đ"))
        XCTAssertNil(VNDParser.parse("0"))
        XCTAssertNil(VNDParser.parse("99999999999999999999999"))
    }

    func testMissingAmountAndFailedPaymentCannotPass() {
        let lines = [
            OCRTextLine(text: "Đơn hàng: #130000001", top:0.1, confidence:0.99),
            OCRTextLine(text: "Thất bại", top:0.15, confidence:0.99),
            OCRTextLine(text: "Số hợp đồng: TESTBILL00001", top:0.2, confidence:0.99),
            OCRTextLine(text: "Tổng tiền: 856.58đ", top:0.3, confidence:0.99)
        ]
        let invoice = try! XCTUnwrap(InvoiceParser.parse(lines).first)
        XCTAssertNil(invoice.amount)
        XCTAssertFalse(invoice.successful)
        XCTAssertFalse(invoice.issues.isEmpty)
    }

    func testDuplicateCodeIsDetected() {
        let a = VerifiedInvoice(orderCode:"130000001", contractCode:"TESTBILL00001", amount:856589)
        XCTAssertTrue(InvoiceValidator.hasDuplicateOrders([a,a]))
    }
}

final class ExcelTests: XCTestCase {
    func testExcelZIPSignatureAndGuard() throws {
        let a = VerifiedInvoice(orderCode: "130000001", contractCode: "TESTBILL00001", amount:856589)
        let b = VerifiedInvoice(orderCode: "130000002", contractCode: "TESTBILL00002", amount:827095)
        let file = try ExcelWriter.create([a, b])
        XCTAssertGreaterThan(file.count, 2000)
        XCTAssertEqual(Array(file.prefix(4)), [0x50,0x4B,0x03,0x04])
        XCTAssertThrowsError(try ExcelWriter.create([a,a]))
        XCTAssertThrowsError(try ExcelWriter.create([]))
    }
}

final class LayoutTests: XCTestCase {
    func testSuccessStatusSlightlyAboveHeaderInRightColumn() {
        let lines = [
            OCRTextLine(text: "Thành công", top:0.096, confidence:0.99),
            OCRTextLine(text: "Đơn hàng: #130000001", top:0.100, confidence:0.99),
            OCRTextLine(text: "Số hợp đồng: TESTBILL00001", top:0.14, confidence:0.99),
            OCRTextLine(text: "Tổng tiền: 856.589đ", top:0.16, confidence:0.99),
            OCRTextLine(text: "Thành công", top:0.296, confidence:0.99),
            OCRTextLine(text: "Đơn hàng: #130000002", top:0.30, confidence:0.99),
            OCRTextLine(text: "Số hợp đồng: TESTBILL00002", top:0.34, confidence:0.99),
            OCRTextLine(text: "Tổng tiền: 827.095đ", top:0.36, confidence:0.99)
        ]
        let data = InvoiceParser.parse(lines)
        XCTAssertEqual(data.count, 2)
        XCTAssertTrue(data[0].successful)
        XCTAssertTrue(data[1].successful)
        XCTAssertEqual(data[0].amount, 856589)
        XCTAssertEqual(data[1].amount, 827095)
    }
}
